<section class="section-lg bg-default decor-text" data-content="Services">
        <div class="container">
          <div class="row row-60">
            <div class="col-md-6 col-xl-4">
              <div class="thumbnail-classic"><a href="single-service.html"><img src="images/portfolio-1-418x315.jpg" alt="" width="418" height="315" loading="lazy"></a>
                <div class="caption">
                  <h5><a class="thumbnail-classic-title" href="single-service.html">Bootstrap Framework</a></h5>
                  <p>theFuture is based on Bootstrap Framework, which makes it a nice template for any purpose.</p>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-xl-4">
              <div class="thumbnail-classic"><a href="single-service.html"><img src="images/portfolio-2-418x315.jpg" alt="" width="418" height="315" loading="lazy"></a>
                <div class="caption">
                  <h5><a class="thumbnail-classic-title" href="single-service.html">Novi Builder</a></h5>
                  <p>Use our Novi Builder to customize and update your website within seconds.</p>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-xl-4">
              <div class="thumbnail-classic"><a href="single-service.html"><img src="images/portfolio-3-418x315.jpg" alt="" width="418" height="315" loading="lazy"></a>
                <div class="caption">
                  <h5><a class="thumbnail-classic-title" href="single-service.html">Responsive &amp; Retina Ready</a></h5>
                  <p>theFuture looks great on any screen resolution and on any device due to its responsiveness.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section><?php /**PATH C:\laragon\www\uxap\resources\views/components/section-eight.blade.php ENDPATH**/ ?>