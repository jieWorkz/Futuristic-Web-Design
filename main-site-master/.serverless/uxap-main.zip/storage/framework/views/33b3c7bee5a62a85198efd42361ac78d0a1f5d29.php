<section class="services section-xl bg-default text-center">
        <div class="bg-decor d-flex align-items-center" data-parallax-scroll="{&quot;y&quot;: 100,  &quot;smoothness&quot;: 30}"><img src="images/bg-decor-1.png" alt="" loading="lazy"/>
        </div>
        <div class="bg-decor d-flex align-items-end" data-parallax-scroll="{&quot;x&quot;: -150, &quot;from-scroll&quot;: 420, &quot;smoothness&quot;: 30}"><img src="images/bg-decor-2.png" alt="" loading="lazy"/>
        </div>
        <div class="bg-decor" data-parallax-scroll="{&quot;x&quot;: 80, &quot;y&quot;: 80,  &quot;smoothness&quot;: 30}"><img src="images/bg-decor-3.png" alt="" loading="lazy"/>
        </div>
        <div class="container">
          <h4 class="heading-decorated">Our Services</h4>
          <!-- Circle carousel-->
          <div class="carousel-wrapper">
            <div class="circle-carousel" data-speed="1000" data-autoplay="5000">
              <!-- slides-->
              <div class="slides">
                <div class="content-box">
                  <div class="content-box-inner">
                    <div class="content-box-img bg-overlay-dark" style="background-image: url(images/service-1.jpg)">
                      <div class="content-title-wrap">
                        <div class="content-title">
                          <h4><a href="single-service.html">Bootstrap Framework</a></h4>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="content-box">
                  <div class="content-box-inner">
                    <div class="content-box-img" style="background-image: url(images/service-2.jpg)">
                      <div class="content-title-wrap">
                        <div class="content-title">
                          <h4><a href="single-service.html">Novi Builder</a></h4>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="content-box">
                  <div class="content-box-inner">
                    <div class="content-box-img" style="background-image: url(images/service-3.jpg)">
                      <div class="content-title-wrap">
                        <div class="content-title">
                          <h4><a href="single-service.html">Responsive & Retina Ready</a></h4>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="content-box">
                  <div class="content-box-inner">
                    <div class="content-box-img bg-overlay-dark" style="background-image: url(images/service-4.jpg)">
                      <div class="content-title-wrap">
                        <div class="content-title">
                          <h4><a href="single-service.html">Tons of Tools for Real Needs</a></h4>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="content-box">
                  <div class="content-box-inner">
                    <div class="content-box-img" style="background-image: url(images/service-5.jpg)">
                      <div class="content-title-wrap">
                        <div class="content-title">
                          <h4><a href="single-service.html">Thought Through Layout</a></h4>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="content-box">
                  <div class="content-box-inner">
                    <div class="content-box-img bg-overlay-dark" style="background-image: url(images/service-6.jpg)">
                      <div class="content-title-wrap">
                        <div class="content-title">
                          <h4><a href="single-service.html">Clean and Crispy Design</a></h4>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="content-box">
                  <div class="content-box-inner">
                    <div class="content-box-img" style="background-image: url(images/service-7.jpg)">
                      <div class="content-title-wrap">
                        <div class="content-title">
                          <h4><a href="single-service.html">Built For Speed</a></h4>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="content-box">
                  <div class="content-box-inner">
                    <div class="content-box-img" style="background-image: url(images/service-8.jpg)">
                      <div class="content-title-wrap">
                        <div class="content-title">
                          <h4><a href="single-service.html">Flexible and Multipurpose</a></h4>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <!-- pagination-->
              <div class="pagination">
                <div class="item">
                  <div class="dot"><i class="linear-icon-pencil-ruler"></i><span></span></div>
                </div>
                <div class="item">
                  <div class="dot"><i class="linear-icon-users"></i><span></span></div>
                </div>
                <div class="item">
                  <div class="dot"><i class="linear-icon-wall"></i><span></span></div>
                </div>
                <div class="item">
                  <div class="dot"><i class="linear-icon-apartment"></i><span></span></div>
                </div>
                <div class="item">
                  <div class="dot"><i class="linear-icon-home4"></i><span></span></div>
                </div>
                <div class="item">
                  <div class="dot"><i class="linear-icon-pencil-ruler2"></i><span></span></div>
                </div>
                <div class="item">
                  <div class="dot"><i class="linear-icon-magic-wand"></i><span></span></div>
                </div>
                <div class="item">
                  <div class="dot"><i class="linear-icon-menu3"></i><span></span></div>
                </div>
              </div>
              <div class="prev"><span>PREV</span></div>
              <div class="next"><span>NEXT</span></div>
            </div>
          </div>
        </div>
      </section><?php /**PATH C:\laragon\www\uxap\resources\views/components/home-rotating-slider.blade.php ENDPATH**/ ?>