<section class="section-lg bg-default text-center">
        <div class="bg-decor d-flex align-items-center justify-content-center" data-parallax-scroll="{&quot;y&quot;: 140, &quot;x&quot;: -50, &quot;smoothness&quot;: 30}"><img src="images/bg-decor-11.png" alt="" loading="lazy">
        </div>
        <div class="container">
          <div class="row row-50 justify-content-sm-center">
            <div class="col-md-10">
              <h5>More plug-ins for better functionality</h5>
              <p>theFuture supports a huge list of plugins developed both by zemez.io and 3rd party developers. Create events, make schedules, book appointments, build restaurant menus, run community, start your features rich online shop and do so many other things with theFuture plugins pack.</p>
            </div>
            <div class="col-md-10">
              <h5>Multiple skins &amp; predesigned pages</h5>
              <p>As Bootstrap offers a lot of possibilities to customize and change your website according to your own wishes, we designed a number of pages, which we hope you will like. They contain everything a modern website owner needs, from store and checkout pages to personal or corporate blog as well as pages to publish some important information about your company.</p>
            </div>
          </div>
        </div>
      </section><?php /**PATH C:\laragon\www\uxap\resources\views/components/section-seven.blade.php ENDPATH**/ ?>