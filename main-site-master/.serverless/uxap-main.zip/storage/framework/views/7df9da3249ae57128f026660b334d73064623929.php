<section class="pre-footer-corporate bg-image-7 bg-overlay-darkest">
        <div class="container">
          <div class="row justify-content-sm-center justify-content-lg-start row-30 row-md-60">
            <div class="col-sm-10 col-md-6 col-lg-10 col-xl-3">
              <!--Brand--><a class="brand" href="index.html"><img class="brand-logo-dark" src="images/logo-default-216x80.png" alt="" width="108" height="40" loading="lazy"><img class="brand-logo-light" src="images/logo-inverse-216x80.png" alt="" width="108" height="40" loading="lazy"></a>
              <p>theFutre is HTML template that fits for both developers and beginners. It comes loaded with an assortment of tools and features that make customization process much easier. A pack of child themes, specially designed for various business niches, allows users to create a fully functional site for any specific business quickly and worry-free.</p>
            </div>
            <div class="col-sm-10 col-md-6 col-lg-3 col-xl-3">
              <h6>Navigation</h6>
              <ul class="list-xxs list-primary">
                <li><a href="#">What We Offer</a></li>
                <li><a href="#">Our Team</a></li>
                <li><a href="#">Our Portfolio</a></li>
                <li><a href="#">Latest Posts</a></li>
                <li><a href="#">Clients</a></li>
              </ul>
            </div>
            <div class="col-sm-10 col-md-6 col-lg-4 col-xl-3">
              <h6>Contacts</h6>
              <ul class="list-xs">
                <li>
                  <dl class="list-terms-minimal">
                    <dt>Address</dt>
                    <dd>4578 Marmora Road, Glasgow, D04 89GR</dd>
                  </dl>
                </li>
                <li>
                  <dl class="list-terms-minimal">
                    <dt>Phones</dt>
                    <dd>
                      <ul class="list-semicolon">
                        <li><a href="tel:#">(800) 123-0045</a></li>
                        <li><a href="tel:#">(800) 123-0045</a></li>
                      </ul>
                    </dd>
                  </dl>
                </li>
                <li>
                  <dl class="list-terms-minimal">
                    <dt>E-mail</dt>
                    <dd><a class="link-primary" href="mailto:#">info@demolink.org</a></dd>
                  </dl>
                </li>
                <li>
                  <dl class="list-terms-minimal">
                    <dt>We are open</dt>
                    <dd>Mn-Fr: 10 am-8 pm</dd>
                  </dl>
                </li>
              </ul>
            </div>
            
            </div>
          </div>
        </div>
      </section><?php /**PATH C:\laragon\www\uxap\resources\views/components/prefooter.blade.php ENDPATH**/ ?>