<section class="section parallax-container context-dark decor-text" data-parallax-img="images/bg-image-6.jpg" data-content="Testimonials">
        <div class="parallax-content">
          <div class="container section-lg text-center">
            <h4 class="heading-decorated">WHAT PEOPLE SAY</h4>
            <!-- Owl Carousel-->
            <div class="owl-carousel" data-items="1" data-stage-padding="15" data-loop="true" data-margin="30" data-dots="true" data-nav="false" data-autoplay="true">
              <div class="item">
                <!-- Quote default-->
                <div class="quote-default">
                  <div class="quote-default__image"><img src="images/deborah-quagmire-120x120.jpg" alt="" width="120" height="120" loading="lazy"/>
                  </div>
                  <div class="quote-default__text">
                    <p class="q">Since I’m not a real pro in web design, I love to use these ready-made and beautifully looking templates. They are available at very affordable prices and they save you a lot of time, and deliver from a lot of sweat and tears!</p>
                  </div>
                  <p class="quote-default__cite">Jane Smith</p>
                </div>
              </div>
              <div class="item">
                <!-- Quote default-->
                <div class="quote-default">
                  <div class="quote-default__image"><img src="images/benedict-arnold-120x120.jpg" alt="" width="120" height="120" loading="lazy"/>
                  </div>
                  <div class="quote-default__text">
                    <p class="q">This template has everything I was looking for my business website to have. From easy-to-customize pages to flawlessly working web tools, theFuture is my number one choice!</p>
                  </div>
                  <p class="quote-default__cite">Kate Wilson</p>
                </div>
              </div>
              <div class="item">
                <!-- Quote default-->
                <div class="quote-default">
                  <div class="quote-default__image"><img src="images/testimonials-3-120x120.jpg" alt="" width="120" height="120" loading="lazy"/>
                  </div>
                  <div class="quote-default__text">
                    <p class="q">Thank you for such an affordable and multipurpose template! It’s easy to configure and use, and what’s more important it looks great. It’s just what I wanted for my website. Keep doing a great job, I’m sure to become a returning customer!</p>
                  </div>
                  <p class="quote-default__cite">Ann Williams</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section><?php /**PATH C:\laragon\www\uxap\resources\views/components/parallax-slider.blade.php ENDPATH**/ ?>