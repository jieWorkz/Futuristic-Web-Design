<section class="section-md bg-default decor-text" data-content="Features">
        <div class="bg-decor d-flex align-items-center" data-parallax-scroll="{&quot;x&quot;: -50,  &quot;smoothness&quot;: 30}"><img src="images/bg-decor-5.png" alt="" loading="lazy"/>
        </div>
        <div class="container">
          <div class="row justify-content-md-center justify-content-lg-between row-50 align-items-center">
            <div class="col-md-8 col-lg-6 position-relative">
              <h4 class="heading-decorated">Impressive Features</h4>
              <!-- Blurb minimal-->
              <article class="blurb blurb-minimal">
                <div class="unit flex-row unit-spacing-md">
                  <div class="unit-left">
                    <div class="blurb-minimal__icon"><span class="icon linear-icon-rocket"></span></div>
                  </div>
                  <div class="unit-body">
                    <p class="blurb__title heading-6">Built for Speed</p>
                    <p>Our template was built for speed and performance. Get the best results at GTmetrix and Google PageSpeed.</p>
                  </div>
                </div>
              </article>
              <!-- Blurb minimal-->
              <article class="blurb blurb-minimal">
                <div class="unit flex-row unit-spacing-md">
                  <div class="unit-left">
                    <div class="blurb-minimal__icon"><span class="icon linear-icon-equalizer"></span></div>
                  </div>
                  <div class="unit-body">
                    <p class="blurb__title heading-6">Flexible and Multipurpose</p>
                    <p>theFuture allows to create various websites for complex and scalable  projects.</p>
                  </div>
                </div>
              </article>
              <!-- Blurb minimal-->
              <article class="blurb blurb-minimal">
                <div class="unit flex-row unit-spacing-md">
                  <div class="unit-left">
                    <div class="blurb-minimal__icon"><span class="icon linear-icon-arrow-down-square"></span></div>
                  </div>
                  <div class="unit-body">
                    <p class="blurb__title heading-6">Social Integration</p>
                    <p>You can easily integrate your Twitter and Facebook accounts with the website using the social widgets.</p>
                  </div>
                </div>
              </article>
            </div>
            <div class="col-md-7 col-lg-4">
              <figure class="image-sizing-1" data-parallax-scroll="{&quot;y&quot;: -50,  &quot;smoothness&quot;: 30}"><img src="images/home-business-1-1481x2068.png" alt="" width="1481" height="2068" loading="lazy"/>
              </figure>
            </div>
          </div>
        </div>
      </section><?php /**PATH C:\laragon\www\uxap\resources\views/components/section-two.blade.php ENDPATH**/ ?>