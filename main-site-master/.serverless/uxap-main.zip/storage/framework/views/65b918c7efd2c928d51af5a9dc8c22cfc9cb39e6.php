<section class="section section-sm context-dark bg-gray-darker section-cta">
        <div class="container">
          <div class="row row-50 align-items-center justify-content-center justify-content-xl-between">
            <div class="col-xl-8 text-xl-start">
              <h4><span class="text-transform-none heading-5">the</span><span class="text-transform-none">FUTURE</span><br><span>is a flexible solution with lots of advantages</span></h4>
              <p>Our template offers you  a variety of elements to be combined.</p>
            </div>
            <div class="col-xl-2 text-xl-end"><a class="button button-primary" target="_blank" href="https://www.templatemonster.com/website-templates/the-future-web-design-multipurpose-html5-website-template-69536.html">Get it now</a></div>
          </div>
        </div>
      </section><?php /**PATH /mnt/c/laragon/www/uxap/resources/views/components/call-to-action.blade.php ENDPATH**/ ?>