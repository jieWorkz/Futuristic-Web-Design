<!DOCTYPE html>
<html class="wide wow-animation" lang="en">
  <head>
    <!-- Site Title-->
    <title>UXAPPILIPINAS | Digital Solutions | Philippines</title>

    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <link rel="icon" href="/favicon.png"/>
    <link rel="canonical" href="https://www.uxappilipinas.com/"/>
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:image" content="https://www.uxappilipinas.com/images/Social%20Media%20Share.png">
    <meta name="twitter:url" content="https://www.uxappilipinas.com/">
    <meta name="twitter:title" content="UXAPPILIPINAS | Digital Solutions | Philippines">
    <meta name="twitter:description" content="UXAPPILIPINAS helps organizations regardless of size and industry transform complex VISIONS into simplified SOLUTIONS. Our solutions include System Automation, Process Mapping, Online Reputation Management, Virtual Workplace and Digital Transformation among many others.">
    <meta property="og:image" content="https://www.uxappilipinas.com/images/Social%20Media%20Share.png">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://www.uxappilipinas.com/">
    <meta property="og:title" content="UXAPPILIPINAS | Digital Solutions | Philippines">
    <meta property="og:description" content="UXAPPILIPINAS helps organizations regardless of size and industry transform complex VISIONS into simplified SOLUTIONS. Our solutions include System Automation, Process Mapping, Online Reputation Management, Virtual Workplace and Digital Transformation among many others.">
    <meta name="keywords" content="UXAPPILIPINAS helps organizations of all sizes and types in transforming their complex processes into simplified digital solutions in the Philippines. Simplified Solutions. Impactful Results. One Digital Software"/>
    <meta name="description" content="UXAPPILIPINAS helps organizations regardless of size and industry transform complex VISIONS into simplified SOLUTIONS. Our solutions include System Automation, Process Mapping, Online Reputation Management, Virtual Workplace and Digital Transformation among many others."/>
<!-- Stylesheets-->
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css2?family=Fira+Sans:ital,wght@0,300;0,600;0,800;1,800&amp;family=Open+Sans:ital,wght@0,300;0,400;1,400&amp;display=swap">
    <link rel="stylesheet" href="<?php echo e(mix('/css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(mix('/css/img.css')); ?>">


      <style>.ie-panel{display: none;background: #212121;padding: 10px 0;box-shadow: 3px 3px 5px 0 rgba(0,0,0,.3);clear: both;text-align:center;position: relative;z-index: 1;} html.ie-10 .ie-panel, html.lt-ie-10 .ie-panel {display: block;}</style>
  </head>
  <body>
      <?php if (isset($component)) { $__componentOriginalcca12856437b420714e3886bdf459ed9c5b0cd3d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Preloader::class, []); ?>
<?php $component->withName('preloader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalcca12856437b420714e3886bdf459ed9c5b0cd3d)): ?>
<?php $component = $__componentOriginalcca12856437b420714e3886bdf459ed9c5b0cd3d; ?>
<?php unset($__componentOriginalcca12856437b420714e3886bdf459ed9c5b0cd3d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <!-- Page-->
    <div class="page">
            <?php if (isset($component)) { $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Header::class, []); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3)): ?>
<?php $component = $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3; ?>
<?php unset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
      <?php if (isset($component)) { $__componentOriginalb868e27777a1713fdabfa6286725856a0499378f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Swiper::class, []); ?>
<?php $component->withName('swiper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalb868e27777a1713fdabfa6286725856a0499378f)): ?>
<?php $component = $__componentOriginalb868e27777a1713fdabfa6286725856a0499378f; ?>
<?php unset($__componentOriginalb868e27777a1713fdabfa6286725856a0499378f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
      
      <?php echo e($slot); ?>


<?php if (isset($component)) { $__componentOriginal121f56d987807f7ecc7f4ac00783a9b1ca82a5d4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Prefooter::class, []); ?>
<?php $component->withName('prefooter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal121f56d987807f7ecc7f4ac00783a9b1ca82a5d4)): ?>
<?php $component = $__componentOriginal121f56d987807f7ecc7f4ac00783a9b1ca82a5d4; ?>
<?php unset($__componentOriginal121f56d987807f7ecc7f4ac00783a9b1ca82a5d4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
     </div>
    <!-- Global Mailform Output-->
    <div class="snackbars" id="form-output-global"></div>
    <!-- Javascript-->
    <script src="<?php echo e(mix('/js/core.min.js')); ?>"></script>
    <script src="<?php echo e(mix('/js/script.js')); ?>"></script>
      <script type="text/javascript" id="zsiqchat">var $zoho=$zoho || {};$zoho.salesiq = $zoho.salesiq || {widgetcode: "fcfea2a334d012e28f5eeb3cab52d3320a0e76ee397917de42dc342b5bd89720", values:{},ready:function(){}};var d=document;s=d.createElement("script");s.type="text/javascript";s.id="zsiqscript";s.defer=true;s.src="https://salesiq.zoho.com/widget";t=d.getElementsByTagName("script")[0];t.parentNode.insertBefore(s,t);</script>
  <!-- Google Tag Manager --><noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-P9FT69" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript><script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start': new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','GTM-P9FT69');</script><!-- End Google Tag Manager --></body>
</html><?php /**PATH /mnt/c/laragon/www/uxap/resources/views/components/layout.blade.php ENDPATH**/ ?>