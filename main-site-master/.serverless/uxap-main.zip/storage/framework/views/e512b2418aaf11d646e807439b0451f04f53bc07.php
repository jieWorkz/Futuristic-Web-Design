<section class="bg-gray-lighter object-wrap decor-text" data-content="About">
        <div class="bg-decor d-flex align-items-center justify-content-end" data-parallax-scroll="{&quot;y&quot;: 50,  &quot;smoothness&quot;: 30}"><img src="images/bg-decor-4.png" alt="" loading="lazy"/>
        </div>
        <div class="section-lg">
          <div class="container">
            <div class="row justify-content-end">
              <div class="col-lg-6 position-relative">
                <h4 class="heading-decorated">About us</h4>
                <p>We are a team of professional, energetic individuals with talented designers and experienced managers available to guide our clients through the flawless and timely execution of any web design project. Since day one, we have been delivering creative and unique websites to our clients worldwide.</p>
                <div class="row row-30">
                  <div class="col-xl-6">
                    <!-- Blurb minimal-->
                    <article class="blurb blurb-minimal">
                      <div class="unit flex-row unit-spacing-md">
                        <div class="unit-left">
                          <div class="blurb-minimal__icon"><span class="icon linear-icon-menu3"></span></div>
                        </div>
                        <div class="unit-body">
                          <p class="blurb__title heading-6"><a href="single-service.html">Bootstrap Framework</a></p>
                          <p>theFuture is based on Bootstrap Framework, which makes it a nice template for any purpose.</p>
                        </div>
                      </div>
                    </article>
                  </div>
                  <div class="col-xl-6">
                    <!-- Blurb minimal-->
                    <article class="blurb blurb-minimal">
                      <div class="unit flex-row unit-spacing-md">
                        <div class="unit-left">
                          <div class="blurb-minimal__icon"><span class="icon linear-icon-users2"></span></div>
                        </div>
                        <div class="unit-body">
                          <p class="blurb__title heading-6"><a href="single-service.html">Clean and Crispy Design</a></p>
                          <p>theFuture is crafted by top industry leaders with love, care and customer needs in mind.</p>
                        </div>
                      </div>
                    </article>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="object-wrap__body object-wrap__body-sizing-1 object-wrap__body-md-left bg-image" style="background-image: url(images/bg-image-1.jpg)"></div>
      </section><?php /**PATH C:\laragon\www\uxap\resources\views/components/section-one.blade.php ENDPATH**/ ?>