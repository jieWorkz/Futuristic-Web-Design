<x-layout>

<x-parallax-container/>

    <x-contact-us/>
</x-layout>