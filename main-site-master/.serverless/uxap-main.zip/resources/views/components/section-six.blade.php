<section class="section-md bg-default">
        <div class="bg-decor d-flex align-items-center justify-content-end" data-parallax-scroll="{&quot;x&quot;: -100, &quot;y&quot;: -30, &quot;smoothness&quot;: 30}"><img src="images/bg-decor-9.png" alt="" loading="lazy">
        </div>
        <div class="container">
          <div class="row justify-content-md-center justify-content-lg-between row-50 align-items-center">
            <div class="col-md-8 col-lg-6">
              <div id="accordion" role="tablist">
                      <!-- Bootstrap card-->
                      <div class="card card-custom">
                        <div class="card-custom-heading" id="accordionHeading1" role="tab">
                          <h5 class="card-custom-title"><a class="collapsed" role="button" data-bs-toggle="collapse" data-parent="#accordion" href="#accordionCollapse1" aria-controls="accordionCollapse1">What are the advantages of purchasing a website template?</a>
                          </h5>
                        </div>
                        <div class="card-custom-collapse collapse" id="accordionCollapse1" role="tabpanel" aria-labelledby="accordionHeading1">
                          <div class="card-custom-body">
                            <p>The major advantage is price: You get a high quality design for just $20-$70. You don’t have to hire a web designer or web design studio. Second advantage is time frame: It usually takes 5-15 days for a good designer to produce a web page of such quality.</p>
                          </div>
                        </div>
                      </div>
                      <!-- Bootstrap card-->
                      <div class="card card-custom">
                        <div class="card-custom-heading" id="accordionHeading2" role="tab">
                          <h5 class="card-custom-title"><a class="collapsed" role="button" data-bs-toggle="collapse" data-parent="#accordion" href="#accordionCollapse2" aria-controls="accordionCollapse2">Do you provide any scripts with your templates or could you do some custom programming?</a>
                          </h5>
                        </div>
                        <div class="card-custom-collapse collapse" id="accordionCollapse2" role="tabpanel" aria-labelledby="accordionHeading2">
                          <div class="card-custom-body">
                            <p>Our templates do not include any additional scripts. Newsletter subscriptions, search fields, forums, image galleries (in HTML versions of Flash products) are inactive. Basic scripts can be easily added at zemez.io If you are not sure that the element you’re interested in is active please contact our Support Chat for clarification.</p>
                          </div>
                        </div>
                      </div>
                      <!-- Bootstrap card-->
                      <div class="card card-custom">
                        <div class="card-custom-heading" id="accordionHeading3" role="tab">
                          <h5 class="card-custom-title"><a class="collapsed" role="button" data-bs-toggle="collapse" data-parent="#accordion" href="#accordionCollapse3" aria-controls="accordionCollapse3">In what formats are your templates available?</a>
                          </h5>
                        </div>
                        <div class="card-custom-collapse collapse" id="accordionCollapse3" role="tabpanel" aria-labelledby="accordionHeading3">
                          <div class="card-custom-body">
                            <p>Website templates are available in Photoshop and HTML formats. Fonts are included with Photoshop file. In most templates HTML is compatible with Adobe®, Dreamweaver® and Microsoft Frontpage®.</p>
                          </div>
                        </div>
                      </div>
              </div>
            </div>
            <div class="col-md-7 col-lg-5 position-relative">
              <figure class="button-shadow"><img src="images/home-variant-3-555x800.jpg" alt="" width="555" height="800" loading="lazy">
              </figure>
            </div>
          </div>
        </div>
      </section>