<section class="section-lg bg-default text-center" data-lightgallery="group">
        <div class="bg-decor d-flex align-items-center" data-parallax-scroll="{&quot;y&quot;: 50,  &quot;smoothness&quot;: 30}" style="transform:translate3d(0px, 24.158px, 0px) rotateX(0deg) rotateY(0deg) rotateZ(0deg) scaleX(1) scaleY(1) scaleZ(1); -webkit-transform:translate3d(0px, 24.158px, 0px) rotateX(0deg) rotateY(0deg) rotateZ(0deg) scaleX(1) scaleY(1) scaleZ(1); "><img src="images/bg-decor-6.png" alt="" loading="lazy">
        </div>
        <div class="container-fluid">
          <h4 class="heading-decorated">Our Portfolio</h4>
          <div class="row row-50">
            <div class="col-md-4 col-xl-3"><a class="thumb-modern" data-lightgallery="item" href="images/portfolio-original-4-1920x1920.jpg">
                <figure><img src="images/portfolio-4-418x315.jpg" alt="" width="418" height="315" loading="lazy">
                </figure>
                <div class="thumb-modern__overlay"></div></a></div>
            <div class="col-md-4 col-xl-3"><a class="thumb-modern" data-lightgallery="item" href="images/portfolio-original-5-1920x1280.jpg">
                <figure><img src="images/portfolio-5-418x315.jpg" alt="" width="418" height="315" loading="lazy">
                </figure>
                <div class="thumb-modern__overlay"></div></a></div>
            <div class="col-md-4 col-xl-3"><a class="thumb-modern" data-lightgallery="item" href="images/portfolio-original-6-1920x1280.jpg">
                <figure><img src="images/portfolio-6-418x315.jpg" alt="" width="418" height="315" loading="lazy">
                </figure>
                <div class="thumb-modern__overlay"></div></a></div>
            <div class="col-md-4 col-xl-3"><a class="thumb-modern" data-lightgallery="item" href="images/portfolio-original-7-1280x1920.jpg">
                <figure><img src="images/portfolio-7-418x315.jpg" alt="" width="418" height="315" loading="lazy">
                </figure>
                <div class="thumb-modern__overlay"></div></a></div>
            <div class="col-md-4 col-xl-3"><a class="thumb-modern" data-lightgallery="item" href="images/portfolio-original-8-1920x1336.jpg">
                <figure><img src="images/portfolio-8-418x315.jpg" alt="" width="418" height="315" loading="lazy">
                </figure>
                <div class="thumb-modern__overlay"></div></a></div>
            <div class="col-md-4 col-xl-3"><a class="thumb-modern" data-lightgallery="item" href="images/portfolio-original-9-1920x1282.jpg">
                <figure><img src="images/portfolio-9-418x315.jpg" alt="" width="418" height="315" loading="lazy">
                </figure>
                <div class="thumb-modern__overlay"></div></a></div>
            <div class="col-md-4 col-xl-3"><a class="thumb-modern" data-lightgallery="item" href="images/portfolio-original-10-1920x1280.jpg">
                <figure><img src="images/portfolio-10-418x315.jpg" alt="" width="418" height="315" loading="lazy">
                </figure>
                <div class="thumb-modern__overlay"></div></a></div>
            <div class="col-md-4 col-xl-3"><a class="thumb-modern" data-lightgallery="item" href="images/slider-slide-14-1280x1920.jpg">
                <figure><img src="images/portfolio-2-418x315.jpg" alt="" width="418" height="315" loading="lazy">
                </figure>
                <div class="thumb-modern__overlay"></div></a></div>
          </div>
        </div>
      </section>