<footer class="footer-corporate bg-gray-darkest">
        <div class="container">
          <div class="footer-corporate__inner">
            <p class="rights"><span>theFuture<span>&nbsp;&copy;&nbsp;</span><span class="copyright-year"></span>. All Rights Reserved.<span>&nbsp;</span><a href="privacy-policy.html">Terms of Use and Privacy Policy</a></span></p>
            <ul class="list-inline-xxs">
              <li><a class="icon icon-xxs icon-primary fa fa-facebook" href="#"></a></li>
              <li><a class="icon icon-xxs icon-primary fa fa-twitter" href="#"></a></li>
              <li><a class="icon icon-xxs icon-primary fa fa-google-plus" href="#"></a></li>
              <li><a class="icon icon-xxs icon-primary fa fa-vimeo" href="#"></a></li>
              <li><a class="icon icon-xxs icon-primary fa fa-youtube" href="#"></a></li>
              <li><a class="icon icon-xxs icon-primary fa fa-pinterest" href="#"></a></li>
            </ul>
          </div>
        </div>
      </footer>
    