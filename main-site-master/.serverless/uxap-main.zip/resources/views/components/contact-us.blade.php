<section class="section-md bg-default decor-text" data-content="Contact">
        <div class="container">
          <div class="row row-50">
            <div class="col-md-5 col-lg-4">
              <h4 class="heading-decorated">Contact Details</h4>
              <ul class="list-sm contact-info">
                <li>
                  <dl class="list-terms-inline">
                    <dt>Address</dt>
                    <dd>4578 Marmora Road, Glasgow, D04 89GR</dd>
                  </dl>
                </li>
                <li>
                  <dl class="list-terms-inline">
                    <dt>Phones</dt>
                    <dd>
                      <ul class="list-semicolon">
                        <li><a href="tel:#">(800) 123-0045</a></li>
                        <li><a href="tel:#">(800) 123-0045</a></li>
                      </ul>
                    </dd>
                  </dl>
                </li>
                <li>
                  <dl class="list-terms-inline">
                    <dt>We are open</dt>
                    <dd>Mn-Fr: 10 am-8 pm</dd>
                  </dl>
                </li>
                <li>
                  <ul class="list-inline-sm">
                    <li><a class="icon-sm fa-facebook icon" href="#"></a></li>
                    <li><a class="icon-sm fa-twitter icon" href="#"></a></li>
                    <li><a class="icon-sm fa-google-plus icon" href="#"></a></li>
                    <li><a class="icon-sm fa-vimeo icon" href="#"></a></li>
                    <li><a class="icon-sm fa-youtube icon" href="#"></a></li>
                    <li><a class="icon-sm fa-pinterest-p icon" href="#"></a></li>
                  </ul>
                </li>
              </ul>
            </div>
            <div class="col-md-7 col-lg-8">
              <h4 class="heading-decorated">Get in Touch</h4>
              <!-- RD Mailform-->
              <form class="rd-mailform rd-mailform_style-1 form-shadow" data-form-output="form-output-global" data-form-type="contact" method="post" action="bat/rd-mailform.php" novalidate="novalidate">
                <div class="form-wrap form-wrap_icon linear-icon-man">
                  <input class="form-input form-control-has-validation" id="contact-name" type="text" name="name" data-constraints="@Required"><span class="form-validation"></span>
                  <label class="form-label rd-input-label" for="contact-name">Your name</label>
                </div>
                <div class="form-wrap form-wrap_icon linear-icon-envelope">
                  <input class="form-input form-control-has-validation" id="contact-email" type="email" name="email" data-constraints="@Email @Required"><span class="form-validation"></span>
                  <label class="form-label rd-input-label" for="contact-email">Your e-mail</label>
                </div>
                <div class="form-wrap form-wrap_icon linear-icon-feather">
                  <textarea class="form-input form-control-has-validation" id="contact-message" name="message" data-constraints="@Required"></textarea><span class="form-validation"></span>
                  <label class="form-label rd-input-label" for="contact-message">Your message</label>
                </div>
                <button class="button button-primary button-shadow" type="submit">send</button>
              </form>
            </div>
          </div>
        </div>
    </section>