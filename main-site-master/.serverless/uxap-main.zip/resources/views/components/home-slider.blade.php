<div class="swiper-container swiper-slider swiper-slider_fullheight swiper-digital" data-effect="circle-bg" data-loop="false" data-autoplay="4600" data-speed="1600" data-mousewheel="false" data-keyboard="false" data-circle-fill="url(#gradient1)">
        <div class="swiper-wrapper">
          <div class="swiper-slide" data-circle-cx=".3" data-circle-cy=".5" data-circle-r=".14" style="background-image: url(images/slider-1.png);">
            <div class="swiper-slide-caption" style="width: 100%">
              <div class="container">
                <div class="row">
                  <div class="col-lg-6 col-xxl-5 d-flex justify-content-center">
                    <div>
                      <h6 class="text-white text-end" data-swiper-anime="{ &quot;animation&quot;: &quot;swiperContentRide&quot;, &quot;duration&quot;: 800, &quot;delay&quot;: 500 }">WEB Agency</h6>
                      <h1 class="text-white" data-swiper-anime="{ &quot;animation&quot;: &quot;swiperContentRide&quot;, &quot;duration&quot;: 800, &quot;delay&quot;: 700 }"><span class="text-lowercase heading-4 text-white">the</span><span>FUTURE</span></h1>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="swiper-slide" data-circle-cx=".7" data-circle-cy=".5" data-circle-r=".2" style="background-image: url(images/slider-2.png);">
            <div class="swiper-slide-caption text-center" style="width: 100%">
              <div class="container">
                <div class="row justify-content-center">
                  <div class="col-lg-8">
                    <h2 class="text-white" data-swiper-anime="{ &quot;animation&quot;: &quot;swiperContentRide&quot;, &quot;duration&quot;: 800, &quot;delay&quot;: 500 }">Built by geeks & used by humans</h2>
                    <h5 class="text-white text-width-2 block-centered" data-swiper-anime="{ &quot;animation&quot;: &quot;swiperContentRide&quot;, &quot;duration&quot;: 800, &quot;delay&quot;: 700 }">theFuture aims to satisfy real needs of real projects. We've got a pack of tools for that.</h5>
                    <div class="group-lg group-middle" data-swiper-anime="{ &quot;animation&quot;: &quot;swiperContentRide&quot;, &quot;duration&quot;: 800, &quot;delay&quot;: 900 }"><a class="button button-black button-shadow" href="#features" data-custom-scroll-to="features">See Features</a><a class="button button-primary button-shadow" href="https://www.templatemonster.com/website-templates/the-future-web-design-multipurpose-html5-website-template-69536.html">Buy template</a></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="swiper-slide" data-circle-cx=".6" data-circle-cy=".5" data-circle-r=".18" style="background-image: url(images/slider-3.png);">
            <div class="swiper-slide-caption d-flex justify-content-center">
              <div>
                <h4 class="text-white text-end" data-swiper-anime="{ &quot;animation&quot;: &quot;swiperContentRide&quot;, &quot;duration&quot;: 800, &quot;delay&quot;: 200 }">New HTML</h4>
                <h1 class="text-white bg-accent p-2 pt-lg-3 ps-lg-3 pe-lg-3" data-swiper-anime="{ &quot;animation&quot;: &quot;swiperContentRide&quot;, &quot;duration&quot;: 800, &quot;delay&quot;: 400 }"><span class="text-lowercase heading-4 text-white">the</span><span>FUTURE</span></h1>
                <h4 class="text-white text-start mt-1" data-swiper-anime="{ &quot;animation&quot;: &quot;swiperContentRide&quot;, &quot;duration&quot;: 800, &quot;delay&quot;: 600 }">Templates Generation</h4>
                <div class="group-lg group-middle" data-swiper-anime="{ &quot;animation&quot;: &quot;swiperContentRide&quot;, &quot;duration&quot;: 800, &quot;delay&quot;: 800 }"><a class="button button-primary button-shadow" href="#features" data-custom-scroll-to="features">See Features</a><a class="button button-black button-shadow" href="https://www.templatemonster.com/website-templates/the-future-web-design-multipurpose-html5-website-template-69536.html">Buy template</a></div>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-pagination"></div>
        <div class="swiper-button-prev linear-icon-chevron-left"></div>
        <div class="swiper-button-next linear-icon-chevron-right"></div>
      </div>