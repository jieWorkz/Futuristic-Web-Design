<section class="section parallax-container context-dark" data-parallax-img="images/parallax-1.jpg">
        <div class="parallax-content">
          <div class="container section-md">
            <div class="row justify-content-md-center row-50">
              <div class="col-md-6 col-lg-3">
                <!-- Box counter-->
                <article class="box-counter">
                  <div class="box-counter__icon linear-icon-coffee-cup"></div>
                  <div class="box-counter-main">
                    <div class="counter">100</div>
                  </div>
                  <p class="box-counter-title">Projects Annually</p>
                </article>
              </div>
              <div class="col-md-6 col-lg-3">
                <!-- Box counter-->
                <article class="box-counter">
                  <div class="box-counter__icon linear-icon-cube"></div>
                  <div class="box-counter-main">
                    <div class="counter">45</div>
                  </div>
                  <p class="box-counter-title">Awards</p>
                </article>
              </div>
              <div class="col-md-6 col-lg-3">
                <!-- Box counter-->
                <article class="box-counter">
                  <div class="box-counter__icon linear-icon-chevrons-expand-horizontal"></div>
                  <div class="box-counter-main">
                    <div class="counter">98</div><span>%</span>
                  </div>
                  <p class="box-counter-title">Positive Reviews</p>
                </article>
              </div>
              <div class="col-md-6 col-lg-3">
                <!-- Box counter-->
                <article class="box-counter">
                  <div class="box-counter__icon linear-icon-mustache-glasses"></div>
                  <div class="box-counter-main">
                    <div class="counter">147</div><span>k</span>
                  </div>
                  <p class="box-counter-title">Happy Customers</p>
                </article>
              </div>
            </div>
          </div>
        </div>
      </section>