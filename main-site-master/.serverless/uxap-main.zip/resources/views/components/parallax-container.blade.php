<section class="section parallax-container context-dark" data-parallax-img="images/parallax-1.jpg"><div class="material-parallax parallax"><img src="images/parallax-1.jpg" alt="" style="display: block; transform: translate3d(-50%, 260px, 0px);"></div><div class="material-parallax parallax"><img src="images/parallax-1.jpg" alt="" style="transform: translate3d(-50%, 260px, 0px); display: block;"></div>
        <div class="parallax-content parallax-header">
          <div class="parallax-header__inner context-dark text-center">
            <div class="parallax-header__content">
              <div class="container">
                <div class="row justify-content-sm-center">
                  <div class="col-md-10 col-xl-8">
                    <h2 class="heading-decorated">About</h2>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
    </section>