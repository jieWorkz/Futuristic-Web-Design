<x-layout>
  <x-home-slider/>
      <!-- Our Services-->
<x-home-rotating-slider/>
      <!-- About us-->
      <x-section-one/>
      <x-section-two/>


      <!-- Call to Action-->
<x-call-to-action/>
      <!-- portfolio-->
 <x-portforlio-section/> 
      <!-- counters-->
      <x-counter-section/>

      <!-- Meet Our Team-->
 <x-team-profile/>
      <!-- Posts-->
<x-section-three/>

      <!-- pricing table-->
<x-pricing/>
<x-parallax-slider/>

      <section class="section-md text-center bg-default">
        <div class="bg-decor d-flex align-items-center justify-content-end" data-parallax-scroll="{&quot;y&quot;: 130, &quot;smoothness&quot;: 30}"><img src="images/bg-decor-4.png" alt="" loading="lazy"/>
        </div>
        <div class="container">
          <h4 class="heading-decorated">Our Clients</h4>
          <div class="row row-30">
            <div class="col-sm-6 col-md-3">
              <figure class="box-icon-image"><a href="#"><img src="images/company-1-126x102.png" alt="" width="126" height="102" loading="lazy"/></a></figure>
            </div>
            <div class="col-sm-6 col-md-3">
              <figure class="box-icon-image"><a href="#"><img src="images/company-2-134x102.png" alt="" width="134" height="102" loading="lazy"/></a></figure>
            </div>
            <div class="col-sm-6 col-md-3">
              <figure class="box-icon-image"><a href="#"><img src="images/company-3-132x102.png" alt="" width="132" height="102" loading="lazy"/></a></figure>
            </div>
            <div class="col-sm-6 col-md-3">
              <figure class="box-icon-image"><a href="#"><img src="images/company-4-126x102.png" alt="" width="126" height="102" loading="lazy"/></a></figure>
            </div>
            <div class="col-sm-6 col-md-3">
              <figure class="box-icon-image"><a href="#"><img src="images/company-5-138x102.png" alt="" width="138" height="102" loading="lazy"/></a></figure>
            </div>
            <div class="col-sm-6 col-md-3">
              <figure class="box-icon-image"><a href="#"><img src="images/company-6-143x102.png" alt="" width="143" height="102" loading="lazy"/></a></figure>
            </div>
            <div class="col-sm-6 col-md-3">
              <figure class="box-icon-image"><a href="#"><img src="images/company-7-109x102.png" alt="" width="109" height="102" loading="lazy"/></a></figure>
            </div>
            <div class="col-sm-6 col-md-3">
              <figure class="box-icon-image"><a href="#"><img src="images/company-8-109x102.png" alt="" width="109" height="102" loading="lazy"/></a></figure>
            </div>
          </div>
        </div>
      </section>
      <!-- Page Footer-->

    </div>
</x-layout>