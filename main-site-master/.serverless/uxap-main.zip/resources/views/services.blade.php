<x-layout>
<x-parallax-container/>

      <x-section-seven/>

      <x-pricing/>

<x-call-to-action2/>

<x-section-eight/>
    
</x-layout>