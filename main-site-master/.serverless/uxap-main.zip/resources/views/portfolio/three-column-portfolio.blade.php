<x-layout>
    <x-parallax-container/>
    <x-three-column-portfolio/>
</x-layout>