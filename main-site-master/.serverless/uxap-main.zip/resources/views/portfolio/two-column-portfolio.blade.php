<x-layout>
    <x-parallax-container/>
    <x-two-column-portfolio/>
</x-layout>