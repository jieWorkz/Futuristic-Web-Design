<x-layout>
    <x-parallax-container/>
    <x-four-column-portfolio/>
</x-layout>