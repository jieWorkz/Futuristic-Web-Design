<x-layout>

<x-parallax-container/>

    <!-- OUR FEATURES -->
<x-section-four/>
      <!-- End of Our Features -->

      <!-- About Us -->
<x-section-five/>

      <!-- Services -->
<x-section-six/>

      <!-- Counters -->
     <x-counter-section/>

      <!-- Testimonials -->
<x-testimonial/>
</x-layout>